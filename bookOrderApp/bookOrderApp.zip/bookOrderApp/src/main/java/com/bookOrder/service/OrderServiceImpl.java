package com.bookOrder.service;

import com.bookOrder.controller.OrderController;
import com.bookOrder.dao.BookDAOImpl;
import com.bookOrder.dao.OrderDAOImpl;
import com.bookOrder.model.Order;
import org.apache.log4j.Logger;

import java.sql.SQLException;
import java.util.List;

public class OrderServiceImpl implements OrderService {
    static final Logger log = Logger.getLogger(OrderController.class);
    int insertStatus;
    int deleteStatus;
    OrderDAOImpl odi=new OrderDAOImpl();
    @Override
    public int createOrder(Order o, String bName) throws SQLException {
        log.info("inside Order Service");

        BookDAOImpl bdi= new BookDAOImpl();
        int bId= bdi.getBookId(bName);
        log.info("in service....   book id returned from book dao is--"+bId);
        o.setBookId(bId);
        OrderDAOImpl odi=new OrderDAOImpl();
      insertStatus = odi.createOrderDAO(o);

        return insertStatus;
    }

    @Override
    public List<Order> getOrder(String authorName) throws SQLException {
        OrderDAOImpl odi=new OrderDAOImpl();

      List<Order> li=  odi.getOrderDAO(authorName);

        return li;
    }



    @Override
    public int deleteOrder(int orderId) throws SQLException {
        OrderDAOImpl odi=new OrderDAOImpl();
       deleteStatus =odi.deleteOrderDAO(orderId);
        return deleteStatus;
    }
}
