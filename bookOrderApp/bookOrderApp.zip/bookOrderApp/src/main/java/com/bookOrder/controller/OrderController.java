package com.bookOrder.controller;

import com.bookOrder.model.Order;
import com.bookOrder.service.OrderServiceImpl;
import com.google.gson.Gson;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;

public class OrderController extends HttpServlet {
    static final Logger log = Logger.getLogger(OrderController.class);
    int insertStatus = 0;
    int deleteStatus = 0;
    int result = 0;

// method to create order
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        PrintWriter out = resp.getWriter();

        String order_by = req.getParameter("orderBy");
        out.println(order_by);
        String book_name = req.getParameter("bookName");
        out.println(book_name);
        int bQuantity = Integer.parseInt(req.getParameter("quantity"));
        out.println(bQuantity);
        LocalDate order_date = LocalDate.now();
        out.println("order date is--" + order_date);
        Order o = new Order();
        o.setOrderDate(String.valueOf(order_date));
        o.setOrderBy(order_by);
        o.setQuantity(bQuantity);
        OrderServiceImpl osi = new OrderServiceImpl();
        try {
            int row = osi.createOrder(o,book_name);
            log.info("no. of rows inserted...."+row);
            out.println("after create order.."+row);
        } catch (SQLException e) {
            log.error("error in order controller");
            e.printStackTrace();
        }

    }

    // method to retrieve data from order table
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {

        Gson gson = new Gson();
        log.info("entered controller...");
        PrintWriter out=resp.getWriter();
        String name=req.getParameter("authorName");


        log.info("author name is..."+name);
        OrderServiceImpl osi=new OrderServiceImpl();
        try {
           List list= osi.getOrder(name);

            String str = gson.toJson(list);
            out.println(str);

            if (list.isEmpty()) {

                log.info("list is empty No tickets available");
            }


        } catch (SQLException e) {
            e.printStackTrace();
            log.error("error in get controller..."+e);
        }

    }

        protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {

        PrintWriter out=resp.getWriter();
        int order_id=Integer.parseInt(req.getParameter("orderId"));
        OrderServiceImpl osi=new OrderServiceImpl();
        try {
            deleteStatus = osi.deleteOrder(order_id);
            log.info("no.of rows deleted---"+deleteStatus);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if(deleteStatus>=1){
            log.info("succesfully deleted");
        }

    }


    }