package com.bookOrder.dao;

import com.bookOrder.model.Order;
import org.junit.Test;

import java.sql.SQLException;

import static org.junit.Assert.*;

public class OrderDAOImplTest {

    OrderDAOImpl odi=new OrderDAOImpl();

    @Test
    public void testDeleteOrder() {

        int orderId=8;
        try {
            odi.deleteOrderDAO(orderId);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.print("error in test..."+e);
        }

    }

    @Test
    public void testCreateOrder() throws SQLException {
        Order o=new Order();
       // o.setOrderId(3);
        o.setOrderDate("2018-08-19");
        o.setOrderBy("uma");
        o.setBookId(5);
        o.setQuantity(12);

        odi.createOrderDAO(o);
        try {
            odi.createOrderDAO(o);
        } catch (SQLException e) {
            System.out.println("error in test.."+e);
            e.printStackTrace();
        }


    }


}